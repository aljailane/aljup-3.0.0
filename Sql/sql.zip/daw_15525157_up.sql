-- phpMyAdmin SQL Dump
-- version 3.5.8.2
-- http://www.phpmyadmin.net
--
-- المزود: sql103.dawnloadgroups.ga
-- أنشئ في: 03 أبريل 2016 الساعة 17:57
-- إصدارة المزود: 5.6.29-76.2
-- PHP إصدارة: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- قاعدة البيانات: `daw_15525157_up`
--

-- --------------------------------------------------------

--
-- بنية الجدول `tbl_users`
--

CREATE TABLE IF NOT EXISTS `tbl_users` (
  `userID` int(11) NOT NULL AUTO_INCREMENT,
  `userName` varchar(20) NOT NULL,
  `userProfession` varchar(50) NOT NULL,
  `userPic` varchar(200) NOT NULL,
  PRIMARY KEY (`userID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=58 ;

--
-- إرجاع أو استيراد بيانات الجدول `tbl_users`
--

INSERT INTO `tbl_users` (`userID`, `userName`, `userProfession`, `userPic`) VALUES
(55, 'ØµÙˆØ±Ø© ØªØ¬Ø±ÙŠØ¨Ù', 'Ø¯Ù†ÙŠÙ„ Ø¬Ø±ÙŠØ§ÙŠØ§ÙŠØ§ Ø³ØªÙŠØªÙŠØªÙŠØª', '5032.jpg'),
(56, 'Ø¹Ø§Ø´Ù‚ Ø§Ù„ÙˆØ±Ø¯', 'Ù…Ù…Ù…Ù…Ù…', '111.jpg'),
(57, 'Ø¹Ø´Ø§Ù‚ Ø§Ù„Ù…Ø­Ø¨Ø', 'Ø±Ù…Ø§Ù†ÙŠ Ø§Ù„Ø¹Ø´Ù‚ ÙŠØ§Ù†Ø¨Ø¶ Ø¹Ø´Ù‚ØªÙ‡', '1346.jpg');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
